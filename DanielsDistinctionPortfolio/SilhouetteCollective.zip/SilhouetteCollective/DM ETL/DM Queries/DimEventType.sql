SELECT
	EventTypeID AS EventType_BK,
	EventType
FROM
	SilhouetteCollective.dbo.EventType;